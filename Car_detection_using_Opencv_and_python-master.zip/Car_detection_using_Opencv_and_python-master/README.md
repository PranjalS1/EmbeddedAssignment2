# Car_detection_using_Opencv_and_python

# ![screenshot 33](https://user-images.githubusercontent.com/40133779/51224108-7ca61e00-196a-11e9-9b66-4255b4592c8d.png)

#![screenshot 34](https://user-images.githubusercontent.com/40133779/51224162-b2e39d80-196a-11e9-9da0-981e0f7f9ac3.png)
